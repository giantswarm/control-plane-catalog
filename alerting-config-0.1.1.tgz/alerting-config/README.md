# alerting-config

Giant Swarm Alertmanager configuration and heartbeat definition, consumed by observability-operator

**Homepage:** <https://github.com/giantswarm/alerting-config>

## Maintainers

| Name | Email | Url |
| ---- | ------ | --- |
| team-atlas | <atlas@giantswarm.io> |  |

## Source Code

* <https://github.com/giantswarm/alerting-config>

## Values

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| managementCluster.name | string | `""` | Cluster name |
| managementCluster.pipeline | string | `""` | Pipeline identifier (e.g. stable, testing) |
| alerting.grafanaAddress | string | `""` | Grafana instance address |
| alerting.slackAPIToken | string | `""` | Slack API token for the default Slack receiver |
| alerting.cronitorHeartbeatPingKey | string | `""` | Cronitor ping key for heartbeat alerts |
| alerting.teams | list | `[]` | List of team-specific configs for per-team PagerDuty routing Expected team contents:  - name: teamA    pagerdutyToken: token-for-teamA |
