{{/* vim: set filetype=mustache: */}}
{{/*
Expand the name of the chart.
*/}}
{{- define "name" -}}
{{- .Chart.Name | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Common labels
*/}}
{{- define "pagerduty-config.labels.common" -}}
app.kubernetes.io/name: {{ include "name" . | quote }}
app.kubernetes.io/managed-by: {{ .Release.Service | quote }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
application.giantswarm.io/team: {{ index .Chart.Annotations "application.giantswarm.io/team" | default "atlas" | quote }}
helm.sh/chart: {{ include "chart" . | quote }}
{{- end -}}

{{/*
Convert a values key (e.g. "lukasz_j", "robin_k") to a valid Kubernetes name segment.
Dots in email-derived keys are stored as underscores by PagerDuty; we replace them with hyphens so we have valid kubernetes resource names.
*/}}
{{- define "pagerduty-config.userName" -}}
{{- . | lower | replace "_" "-" }}
{{- end }}

{{/*
Render the spec block for a Schedule resource.
Context must be a dict with keys:
  - schedule:       the schedule values object
  - restrictions:   the resolved restriction list
  - displayName:    the display name (e.g. "atlas On-Call Schedule")
  - externalName:   the PagerDuty ID for crossplane.io/external-name
  - resourceName:   the Kubernetes metadata.name
  - levelIndex:     rotation offset index (0 = primary, 1+ = offset by N turns)
  - root:           the root $ context (for .Values)
  - observeOnly:    (optional) if true, set managementPolicies to ["Observe"]
*/}}
{{- define "pagerduty-config.scheduleResource" -}}
{{- $schedule := .schedule }}
{{- $restrictions := .restrictions }}
{{- $root := .root }}
{{- /* Go reference time layout for ISO 8601 with numeric timezone offset */ -}}
{{- $iso8601 := "2006-01-02T15:04:05-07:00" }}
{{- $offsetSeconds := mul .levelIndex $root.Values.scheduleDefaults.rotationTurnLengthSeconds }}
{{- $baseTime := toDate $iso8601 $root.Values.scheduleDefaults.layerStart }}
{{- $offsetTime := dateModify (printf "+%ds" $offsetSeconds) $baseTime }}
{{- $rotationVirtualStart := $offsetTime | date $iso8601 }}
---
apiVersion: schedule.pagerduty.crossplane.io/v1alpha1
kind: Schedule
metadata:
  name: {{ .resourceName }}
  labels:
    {{- include "pagerduty-config.labels.common" $root | nindent 4 }}
  {{- if .externalName }}
  annotations:
    crossplane.io/external-name: {{ .externalName }}
  {{- end }}
spec:
  {{- if .observeOnly }}
  managementPolicies: ["Observe"]
  {{- end }}
  forProvider:
    name: {{ .displayName }}
    description: "Managed by Crossplane (pagerduty-config)"
    timeZone: {{ $root.Values.scheduleDefaults.timeZone }}
    layer:
      - name: "On-Call Rotation"
        rotationTurnLengthSeconds: {{ $root.Values.scheduleDefaults.rotationTurnLengthSeconds }}
        start: {{ $root.Values.scheduleDefaults.layerStart | quote }}
        rotationVirtualStart: {{ $rotationVirtualStart | quote }}
        {{- /* Reference User CRs by Kubernetes name (user-<key>) */}}
        userRefs:
          {{- range $schedule.users }}
          - name: user-{{ include "pagerduty-config.userName" . }}
          {{- end }}
        restriction:
          {{- range $restrictions }}
          - type: {{ .type }}
            startTimeOfDay: {{ .startTimeOfDay | quote }}
            durationSeconds: {{ .durationSeconds }}
            startDayOfWeek: {{ .startDayOfWeek }}
          {{- end }}
  providerConfigRef:
    name: {{ $root.Values.providerConfigName }}
{{- end }}
