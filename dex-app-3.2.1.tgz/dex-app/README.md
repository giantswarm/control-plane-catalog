[![CircleCI](https://dl.circleci.com/status-badge/img/gh/giantswarm/dex-app/tree/main.svg?style=svg)](https://dl.circleci.com/status-badge/redirect/gh/giantswarm/dex-app/tree/main)

# Dex

[Dex](https://dexidp.io/) is an identity service that uses OpenID Connect to handle authentication for Kubernetes. It connects to third party identity providers like Active Directory, LDAP, and GitHub. While the Kubernetes API server only supports a single identity provider and OIDC token issuer, the use of Dex allows to use identities from various providers when authenticating for Kubernetes.

This app is installed in Giant Swarm management clusters by default and is also ready to be deployed in workload clusters.

In addition to Dex itself, this app provides [Dex K8s Authenticator](https://github.com/mintel/dex-k8s-authenticator), which helps to configure `kubectl` for clusters authenticated to via Dex.

## Installing

There are several ways to install this app.

1. [Using our web interface](https://docs.giantswarm.io/ui-api/web/app-platform/#installing-an-app)
2. Creating the [App resource](https://docs.giantswarm.io/ui-api/management-api/crd/apps.application.giantswarm.io/) in the management cluster. Check the [getting started with app platform](https://docs.giantswarm.io/app-platform/getting-started/) guide for details.

## Configuring

You provide your configration via a custom `values.yaml` file. Here is an example using the connector for Azure Active Directory. More connector examples can be found below.

```yaml
isWorkloadCluster: true
services:
  kubernetes:
    api:
      caPem: |
        -----BEGIN CERTIFICATE-----
        M...=
        -----END CERTIFICATE-----
oidc:
  expiry:
    signingKeys: 6h
    idTokens: 30m
  customer:
    connectors:
    - id: customer
      connectorName: test
      connectorType: microsoft
      connectorConfig: |-
        clientID: <CLIENT-ID-SET-IN-YOUR-IdP>
        clientSecret: <CLIENT-SECRET-SET-IN--YOUR-IdP>
        tenant: <TENANT-SET-SET-IN--YOUR-IdP>
        redirectURI: https://dex.<CLUSTER>.<BASEDOMAIN>/callback
```

Some notes:

- `.service.kubernetes.api.caPem` is the CA certificate of your workload cluster in PEM format. At Giant Swarm, you can retrieve this certificate via the [kubectl gs login](https://docs.giantswarm.io/ui-api/kubectl-gs/login/) command, when creating a client certificate for the workload cluster. It ends up in Base46-encoded form in your kubectl config file. The CA certificate is required by Dex K8s Authenticator.

- The `redirectURI` in your connector configuration must contain the proper host name for Dex's own ingress. In the default form, it contains the workload cluster name (replace `<CLUSTER>` with the actual name) and a base domain (replace `<BASEDOMAIN>` with the proper base domain).

- If you configure more than one connector, make sure to set a unique `id` for each one. Be aware that this version of Dex is configured to prefix all user group names with the connector ID. So if your connector's `id` is `customer`, a membership in group `devops` will appear as `customer:devops`.

### Other connector types

Example connector configuration for Keycloak:

```yaml
    - id: customer
      connectorName: test
      connectorType: oidc
      connectorConfig: |-
        clientID: <CLIENT-ID-SET-IN-YOUR-IdP>
        clientSecret: <CLIENT-SECRET-SET-IN--YOUR-IdP>
        insecureEnableGroups: true
        scopes:
        - email
        - groups
        - profile
        issuer: https://<IDP_ENDPOINT>/auth/realms/master
        redirectURI: https://dex.<CLUSTERID>.<BASEDOMAIN>/callback
```

Example connector configuration for GitHub:

```yaml
    - id: customer
      connectorName: test
      connectorType: github
      connectorConfig: |-
        clientID: <CLIENT-ID-SET-IN-YOUR-IdP>
        clientSecret: <CLIENT-SECRET-SET-IN--YOUR-IdP>
        loadAllGroups: false
        teamNameField: slug
        orgs:
        - name: <GITHUB_ORG_NAME>
          teams:
          - <GITHUB_TEAM_SLUG>
        redirectURI: https://dex.<CLUSTERID>.<BASEDOMAIN>/callback
```

Note:

- `<GITHUB_ORG_NAME>` is your GitHub organization name. For example, the part `myorg` in `https://github.com/myorg`.
- `<GITHUB_TEAM_SLUG>` is the part of the team's URL representing the team name. For example, the part `my-team` in `https://github.com/orgs/myorg/teams/my-team`.

### Installing the Chart in Giant Swarm workload clusters

The app is installed in workload clusters, via our [app platform](https://docs.giantswarm.io/app-platform/).
Before doing so, please create the following `ConfigMap` resource in the namespace named after that workload cluster to provide the contents of your `values.yaml` file.

```yaml
apiVersion: v1
kind: ConfigMap
metadata:
  name: dex-app-user-values
  namespace: <CLUSTER>
data:
  values: |
    <content of values.yaml>
```

Then you either install the app via our web UI, or you'll create an App resource in the following format:

```yaml
apiVersion: application.giantswarm.io/v1alpha1
kind: App
metadata:
  labels:
    app.kubernetes.io/name: dex-app
  name: dex-app
  namespace: <CLUSTER>
spec:
  catalog: giantswarm-playground
  name: dex-app
  namespace: dex
  userConfig:
    configMap:
      name: <CONFIGMAPNAME>
      namespace: <CLUSTER>
```

Notes:

- `<CONFIGMAPNAME>` must be replaced with the name of the ConfigMap resource shown above.
- `<CLUSTER>` is replaced with the name of your workload cluster.

As a result, you should see Dex deployed in your workload cluster.

### Ingress, TLS and custom certification authorities

Dex app exposes a web interface, which is accessible over https. Therefore, it creates an ingress, which needs to be configured with a TLS certificate signed by a certification authority, which needs to be trusted by the browsers.
The app consists of several components, which also need to be able to communicate with each other internally over https. So the certification authority signing the certificates needs to be trusted by the individual app components as well.

By default, the app will use cert-manager to issue a TLS certificate signed by Let's Encrypt. To use a custom cert-manager ClusterIssuer, change the value of the `ingress.tls.clusterIssuer` property in the user values.

```yaml
ingress:
  tls:
    clusterIssuer: my-custom-cluster-issuer
```

To disable the automatic certificate generation by cert-manager and use a custom TLS certificate instead, set the `ingress.tls.clusterIssuer` property to a falsy value (for example an empty string) in the user values:

```yaml
ingress:
  tls:
    clusterIssuer: ""
```

Then create a Secret in the `dex` namespace, which contains the TLS certificate and private key in the following format:

```yaml
apiVersion: v1
kind: Secret
type: kubernetes.io/tls
metadata:
  name: dex-tls
data:
  ca.crt: ...
  tls.crt: ...
  tls.key: ...
```

In case a custom certification authority is used, it needs to be exposed to the individual app components and set as trusted, otherwise the components will not be able to communicate with each other and the app may not work as expected. This can be achieved by providing an additional set of values to the app configuration:

Provide a reference to an existing Secret resource, which contains the custom certification authority:

```yaml
trustedRootCA:
  name: ca.crt
  secretName: "name-of-the-custom-ca-secret"
```

The referenced Secret needs to be created in the `dex` namespace and contain the custom CA certificate in a property with a name matching the one set in the user values (`trustedRootCA.name`):

```yaml
apiVersion: v1
kind: Secret
type: Opaque
metadata:
  name: name-of-the-custom-ca-secret
data:
  ca.crt: ...
```

### Proxy configuration

In case the traffic to Dex needs to go through a proxy (for example when the app is installed in a private cluster), the individual components of the app need to be set up to use the proxy.

The proxy setup can be provided to the app in a specific section of the user values configmap or secret with the app configuration:

```yaml
cluster:
  proxy:
    http: "https://proxy.host:4040" # hostname of the proxy for HTTP traffic
    https: "https://proxy.host:4040" # hostname of the proxy for HTTPS traffic
    noProxy: "kubernetes-api-ip-range" # comma-separated list of hostnames and IP ranges, whose traffic should not go through the proxy. # Kubernetes API IP range needs to be defined here in order for Dex to work correctly
```

### Static clients

In addition to a few pre-defined static clients Dex app supports the possibility to define custom static clients as well.
They need to be defined as an array of object in a specific property of the configuration yaml file called `extraStaticClients`.
The structure of each custom static client object is exactly the same as in upstream Dex, plus `secretRef`:

```yaml
extraStaticClients:
- id: "client-id"
  secret: "client-secret"
  trustedPeers:
  - "https://example.com"
  public: true
  name: "client-name-1"
  logoURL: "https://example.com/logo"
- idEnv: "CLIENT_ID"
  secretEnv: "CLIENT_SECRET"
  redirectURIs:
  - "https://example.com/redirect"
  name: "client-name-2"
- id: "client-id-3"
  secretRef:
    name: "dex-client-client-id-3"
    key: "secret"
  redirectURIs:
  - "https://example.com/redirect"
  name: "client-name-3"
```

**Notes:**

- `id` and `idEnv` properties are mutually exclusive
- `secret`, `secretEnv` and `secretRef` properties are mutually exclusive; a client that is not `public` needs exactly one of them, otherwise the chart fails to render naming the client
- Required properties:
  - `name`
  - `id` or `idEnv`
  - `secret`, `secretEnv` or `secretRef` (unless `public: true`)

Extra static clients can also be configured as trusted peers of the pre-defined static clients:

**Add the extra static client id to the list of `trustedPeers` in the pre-defined static client:**

```yaml
staticClients:
  dexK8SAuthenticator:
    clientAddress: "dex.installation.basedomain.io"
    clientSecret: "default-client-dex-authenticator-secret"
    trustedPeers:
    - "client-id"
extraStaticClients:
- id: "client-id"
  name: "client-name-1"
  secret: "client-secret"
```

It will produce the same configuration:

```yaml
staticClients:
- id: dex-k8s-authenticator
  name: dex-k8s-authenticator
  secret: default-client-dex-authenticator-secret
  trustedPeers:
  - client-id
- id: client-id
  name: client-name-1
  secret: client-secret
  public: true
```
Duplicities are prevented in case an ID of any additional trusted peer equals an automatically pre-populated trusted peer ID.

#### Client secrets from a Secret

A client secret does not have to be written into the values: `secretRef: {name, key}` in an extra static client, or `clientSecretRef: {name, key}` next to `clientID` in a pre-defined one (`gitopsui`, `muster`, `mcpKubernetes`, `mcpCapi`, `mcpPrometheus`, `dexK8SAuthenticator`), names a key of a Secret in dex's namespace. The chart sets the environment variable `DEX_CLIENT_SECRET_<ID>` on the dex container from that key (`<ID>` is the client id in upper case with every character other than a letter or a digit replaced by `_`) and writes the client into the dex configuration with `secretEnv: DEX_CLIENT_SECRET_<ID>`, which dex reads when it starts. Whoever declares the client creates the Secret, so a client is added by a new Secret and a plaintext list entry, without touching the values that carry the other clients' secrets.

```yaml
oidc:
  staticClients:
    muster:
      clientID: muster
      clientSecretRef:
        name: dex-client-muster
        key: secret
      redirectURI: https://muster.example.com/callback
  extraStaticClients:
  - id: platform-manager
    name: Platform manager
    secretRef:
      name: dex-client-platform-manager
      key: secret
    redirectURIs:
    - https://platform-manager.example.com/callback
```

- At most one of the inline secret and the reference per client; both fails the render naming the client. A pre-defined client (`gitopsui`, `muster`, `mcpKubernetes`, `mcpCapi`, `mcpPrometheus`) with a `clientID` and neither is left out of the configuration and named in the release notes (`helm get notes`), so values shared by several installations can declare a client whose secret only some of them carry. An extra static client that is not `public` needs one; so does `dexK8SAuthenticator`, whose `clientSecret` has a chart default: its `clientSecretRef` goes together with `clientSecret: ""`.
- `secretRef` needs a literal `id` (not `idEnv`), and two client ids must not map to the same variable name.
- A referenced Secret or key that does not exist keeps the dex pod from starting (`CreateContainerConfigError`) instead of running the client with an empty secret.
- dex reads the environment at start-up: a rotated referenced Secret takes effect on the next roll of the dex Deployment (for example `kubectl -n <namespace> rollout restart deployment dex`).

## Update Process

Giant Swarm is currently building the `dex` app from [a fork](https://github.com/giantswarm/dex) of the [original project](https://github.com/dexidp/dex).
We implement additional logic which adds the connector id as prefix to user groups.
In order to update the image used in this chart it is currently needed to to do the following steps in our fork repo:

- Fetch upstream changes.
- Ensure that our commits with prefixing logic on token creation _and_ refresh are present on the branch we want to release from.
- Ensure CircleCI builds are green
- Create the version tag with -gs suffix to push the image to our registry

Then in this repo:

- Update the image version tag
- Test the new version before releasing. Make sure to test token refresh as well.

## Release Process

- Ensure CHANGELOG.md is up to date.
- In case of changes to `values.yaml`, ensure that `values.schema.json` is updated to reflect all values and their types correctly.
- Create a branch `master#release#v<major.minor.patch>`, wait for the according release PR to be created, approve it, merge it.
- This will push a new git tag and trigger a new tarball to be pushed to the
[control-plane-catalog](https://github.com/giantswarm/control-plane-catalog).
