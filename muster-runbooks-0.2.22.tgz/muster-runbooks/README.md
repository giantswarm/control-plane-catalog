# muster-runbooks

Muster Workflow CRs implementing alert triage runbooks for the Giant Swarm
Agent Platform. Each workflow encodes the read-only investigation steps for
one alert, executed via the muster MCP aggregator.

**Homepage:** <https://github.com/giantswarm/muster-runbooks>

## Source Code

* <https://github.com/giantswarm/muster-runbooks>

## Values

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| global | object | `{}` |  |
