package falcoTemplates

import (
	"github.com/falcosecurity/falco/chart/falco/tests/unit"
	"github.com/gruntwork-io/terratest/modules/helm"
	"github.com/stretchr/testify/require"
	corev1 "k8s.io/api/core/v1"
	"path/filepath"
	"strings"
	"testing"
)

func TestServiceAccount(t *testing.T) {
	t.Parallel()

	helmChartPath, err := filepath.Abs(unit.ChartPath)
	require.NoError(t, err)

	testCases := []struct {
		name     string
		values   map[string]string
		expected func(t *testing.T, sa *corev1.ServiceAccount)
	}{
		{
			"defaultValues",
			nil,
			func(t *testing.T, sa *corev1.ServiceAccount) {
				require.Equal(t, sa.Name, "rendered-resources-falco")
			},
		},
		{
			"kind=auto",
			map[string]string{
				"serviceAccount.create": "false",
			},
			func(t *testing.T, sa *corev1.ServiceAccount) {
				require.Equal(t, sa.Name, "")
			},
		},
		{
			"customLabels",
			map[string]string{
				"serviceAccount.labels.app\\.kubernetes\\.io/part-of": "my-app",
				"serviceAccount.labels.team":                           "platform",
			},
			func(t *testing.T, sa *corev1.ServiceAccount) {
				require.Equal(t, "my-app", sa.Labels["app.kubernetes.io/part-of"])
				require.Equal(t, "platform", sa.Labels["team"])
			},
		},
	}

	for _, testCase := range testCases {
		testCase := testCase

		t.Run(testCase.name, func(t *testing.T) {
			t.Parallel()

			options := &helm.Options{SetValues: testCase.values}
			output, err := helm.RenderTemplateE(t, options, helmChartPath, unit.ReleaseName, []string{"templates/serviceaccount.yaml"})
			if err != nil {
				require.True(t, strings.Contains(err.Error(), "Error: could not find template templates/serviceaccount.yaml in chart"))
				return
			}

			var sa corev1.ServiceAccount
			helm.UnmarshalK8SYaml(t, output, &sa)

			testCase.expected(t, &sa)
		})
	}
}
